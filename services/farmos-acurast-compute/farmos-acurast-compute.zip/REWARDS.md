# FARMOS Acurast deployment reward guidance

## Stratus C7 (Android)
- Deployment: farmos-compute-service
- Execution type: onetime
- Processor address: 5C4iuPWJMooQkEuz1jJHPM9UPSwWAY7HdZjoJHwarh1EnbFS
- Suggested reward: max out as much as possible for the old phone
- Reason: old phone, push reward higher to maximize earnings

## iPhone (iOS)
- Deployment: farmos-iphone-compute-service
- Execution type: interval, repeat
- Processor address: 5EgBZuiRnCfFzvBjgHitNymetm9daFoxEry8vn65sE4QErTj
- Suggested reward: 0.0005 ACU per execution
- Reason: lightweight service, repeated runs

## Notes
- Rewards are per execution, in ACU.
- For the C7, set the reward as high as the Hub/deployment model allows for a short compute run.
- The published Hub job reward is what matters for payout, not the config file alone.
- Actual execution and settlement depend on the Acurast network and processor eligibility.
